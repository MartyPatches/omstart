var gulp = require('gulp');
var plumber = require('gulp-plumber');
var rename = require('gulp-rename');
var autoPrefixer = require('gulp-autoprefixer');
var cssComb = require('gulp-csscomb');
var cmq = require('gulp-combine-media-queries');
var minifyCss = require('gulp-minify-css');
var browserify = require('gulp-browserify');
var uglify = require('gulp-uglify');
gulp.task('css',function(){
	gulp.src(['css/src/**/*.css'])
		.pipe(plumber({
			handleError: function (err) {
				console.log(err);
				this.emit('end');
			}
		}))
		.pipe(autoPrefixer())
		.pipe(cssComb())
		.pipe(cmq())
		.pipe(gulp.dest('css/dist'))
		.pipe(rename({
			suffix: '.min'
		}))
		.pipe(minifyCss())
		.pipe(gulp.dest('css/dist'));
});
gulp.task('js',function(){
	gulp.src(['js/src/**/*.js'])
		.pipe(plumber({
			handleError: function (err) {
				console.log(err);
				this.emit('end');
			}
		}))
  		.pipe(browserify())
		.pipe(gulp.dest('js/dist'))
		.pipe(rename({
			suffix: '.min'
		}))
		.pipe(uglify())
		.pipe(gulp.dest('js/dist'));
});
gulp.task('html',function(){
	gulp.src(['html/**/*.html'])
		.pipe(plumber({
			handleError: function (err) {
				console.log(err);
				this.emit('end');
			}
		}))
		.pipe(gulp.dest('./'));
});
gulp.task('default',function(){
	gulp.watch('js/src/**/*.js',['js']);
	gulp.watch('css/src/**/*.css',['css']);
	gulp.watch('html/**/*.html',['html']);
});
